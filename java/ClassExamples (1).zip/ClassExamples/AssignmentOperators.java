package day3;

public class AssignmentOperators {

	public static void main(String[] args) {
		
		//Assignment   =   +=   -=   *= /=  %=
		// Shorthand operators  +=   -=   *= /=  %=
		
		// increment more values  +=
		
		int a=10;   // =
		
		//a=a+5;
		//a+=5;
		
		//a=a-5;
		a-=5;
		
		System.out.println(a); //15
		
		
		// *= /=  %=
		
		int x=5;
		
		//x=x*2;
		//x*=2;
		
		//x=x/2;
		//x/=2;
		
		//x=x%2;
		x%=2;
		
		
		System.out.println(x);  //2
		
		
	}

}
