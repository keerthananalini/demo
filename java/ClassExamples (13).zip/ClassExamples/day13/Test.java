package day13;

public class Test {

	//private
	/*private int x=100;
	
	private void m1()
	{
		System.out.println("this is m1 method....");
	}*/
	
	//default
	
	/*int x=100;
	
	void m1()
	{
		System.out.println("this is m1 method....");
	}*/
	
	/*protected int x=100;
	
	protected void m1()
	{
		System.out.println("this is m1 method....");
	}*/
	
	public int x=100;
	
	public void m1()
	{
		System.out.println("this is m1 method....");
	}


	
	
	
}
