package day4;

public class EvenOrOddNumber {

	public static void main(String[] args) {
		
		int num=10;
		
		if(num%2==0)
		{
			System.out.println("Number is Even");
		}
		else
		{
			System.out.println("Number is Odd");
		}
		

	}

}
