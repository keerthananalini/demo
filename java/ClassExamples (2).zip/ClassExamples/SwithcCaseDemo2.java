package day4;

public class SwithcCaseDemo2 
{

	public static void main(String[] args) 
	{
		
		int person_age=15;
		
	
		switch(person_age)
		{
		
		case: (person_age<15): System.out.println("Eligible for vote");
		
		
		}
		
			
	}

}
