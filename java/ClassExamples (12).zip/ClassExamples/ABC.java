package day12;

public interface ABC {

	int x=100;
	void m1();
}
