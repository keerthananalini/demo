package day12;

public interface XYZ {

	int y=200;
	
	void m2();
}
