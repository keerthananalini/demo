package day12;

public class MNO {

	int z=300;
	
	void m3()
	{
		System.out.println("this is m3 from MNO");
		System.out.println(z);
	}
}
