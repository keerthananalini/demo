package day11;

public class TestSuper {

	public static void main(String[] args) 
	{
		
		Dog d=new Dog();
		d.displayColor();
		
		d.eat();
		
	}

}
