package day11;

/*class ABC
{
	
}



class XYZ
{
	
	
	
}*/


/*class mno extends ABC,XYZ
{
	
	
	
}*/





public class MultipleInheritence {

	public static void main(String[] args) {
	
		ABC abcobj=new ABC();
		
		XYZ xyzobj=new XYZ();
		
		xyzobj.
	
		
	}

}
