package day2;

public class NumbersStrings {

	public static void main(String[] args) {
		
		//int a=123;
		//String s="123";  //valid
		
		//int s="123";  // invalid
		
		//System.out.println();   // ctrl+space     cmd+space
		
		System.out.println("welcome"+100);
		System.out.println("welcome"+"100");
		
		System.out.println("10"+"20"); //1020
		
		System.out.println(10+20); //30
		
		
		
		

	}

}
