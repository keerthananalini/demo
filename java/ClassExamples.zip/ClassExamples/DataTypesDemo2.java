package day2;

public class DataTypesDemo2 {

	public static void main(String[] args) {
		
		// Numeric - integer data types
		
		int a=100, b=200;
		
		System.out.println("The value of a is:"+a);
		System.out.println("The value of b is:"+b);
		
		long x=1234567889;
		System.out.println("The value of x is:"+x);
		
		byte by=100;
		System.out.println("The value of by is:"+by);
		
		short sh=32765;
		System.out.println("The value of sh is: "+sh);
		
		//decimal numbers - float, double
		
		float item_price=15.505F;
		System.out.println(item_price);
		
		double d=1234.65645645;
		System.out.println(d);
		
		 
		double du=125;   // valid
		System.out.println(du);
		
		//int it=10.5;   // not valid
		
		
		char grad='A';
		System.out.println("The grad of the stdent is:"+grad);
		
		boolean bo=true;
		System.out.println(bo);
		
		//boolean bol="true";   // invalid
		
		
		
		String person_name="John kenedy";
		System.out.println("The name of the person is:"+person_name);
		
		String str="A";  //Valid
		System.out.println(str);
		
		
		//char ch='Abc';  // In valid
		
		//String sr=true; //invalid
		String sr="true"; //valid
		
		
	
	
	}

}
