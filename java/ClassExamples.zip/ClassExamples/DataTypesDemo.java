package day2;

public class DataTypesDemo 
{

	public static void main(String[] args) 
	{
		
		//int a;    // declaration
		//a=100;     // Assignment
		
		//int a=100;   // declaration+assignment
		
		//System.out.println("welcome");
		//System.out.println(10);
		
		//System.out.println(a);
		
		//Variables in multiple lines
		//Appraoch1
		//int a=100;
		//int b=200;
		//int c=300;
		
		//Appraoch2
		//int a,b,c;
		//a=100;
		//b=200;
		//c=300;
		
		//Appraoch3
		int a=100,b=200,c=300;
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
		System.out.println(a+b+c); //600  addition
		
		System.out.println(a+"  "+b+"   "+c);  //100  200   300
		
		
		System.out.println("the value of a is:"+a);
		System.out.println("the value of b is:"+b);
		System.out.println("the value of c is:"+c);
		
		
		
	}

}
