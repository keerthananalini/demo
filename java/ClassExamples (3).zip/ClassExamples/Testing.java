package day5;

import javax.swing.plaf.synth.SynthOptionPaneUI;

public class Testing {

	public static void main(String[] args) {

		for (int i = 0; i <= 10; i++) {
			System.out.println(i);
		}

	}

}


//  alighment of code  ctrl+ shift +f
//  cmd+shift+f