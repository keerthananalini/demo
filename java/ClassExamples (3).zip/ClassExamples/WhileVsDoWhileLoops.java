package day5;

public class WhileVsDoWhileLoops {

	public static void main(String[] args) {
		
		
		/*int i=10;
		
		while(i<=5)
		{
			System.out.println(i);
			i++;
		}
		*/
		
		int i=10;
		
		do
		{
			System.out.println(i);
			i++;
			
		}while(i<=5);
		
			
		

	}

}
